# n200-doc
The purpose of this repo is to hold the document for the commercial Nuclei N200 processor core series. 
